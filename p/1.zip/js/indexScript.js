function startbclf()
{
    //alert("startButtonClicked");
    new Audio('audio/click.mp3').play();
    document.location.href="q0.html";
}