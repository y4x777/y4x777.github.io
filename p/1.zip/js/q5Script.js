let countTrueAns = 0;
let lockbt0 = false;
let lockbt1 = false;
let lockbt2 = false;
let lockbt3 = false;
let lockbt4 = false;
let lockbt5 = false;
function img0clf()
{
    //alert("Не угадали");
    new Audio('audio/error.mp3').play(); 
    //document.getElementById("divAns0").style.backgroundColor = "#FF0000";
    document.getElementById("ansImg0").hidden = false;
}

function button0clf()
{
    img0onmouseoverf();

    new Audio('audio/error.mp3').play(); 
        document.getElementById("button0").style.backgroundColor = "#FF0000";
        //document.getElementById("ansImg2").hidden = false;
        document.getElementById("ansImg0").hidden = false;
    if (!lockbt0 && countTrueAns<2)
        {
            lockbt0 = true;
            //alert("btn0clicked " + countTrueAns);
    }
    else
    {
        //document.getElementById("nextButton").hidden = false;
    }
}

function button1clf()
{

    img1onmouseoverf();

    new Audio('audio/ok.mp3').play(); 
    document.getElementById("button1").style.backgroundColor = "#00FF00";
    //document.getElementById("ansImg2").hidden = false;
    document.getElementById("ansImg1").hidden = false;
    if (!lockbt1 && countTrueAns<2)
    {
    countTrueAns++;
    //alert("btn1clicked " + countTrueAns);
    lockbt1 = true;
    }
    else
    {
        document.getElementById("nextButton").hidden = false;
    }
}

function button2clf()
{

    img2onmouseoverf();

    //alert("Не угадали");
    new Audio('audio/ok.mp3').play(); 
    document.getElementById("button2").style.backgroundColor = "#00FF00";
    //document.getElementById("ansImg3").hidden = false;
    document.getElementById("ansImg2").hidden = false;
    if (!lockbt2 && countTrueAns<2)
    {
    countTrueAns++;
    //alert("btn2clicked " + countTrueAns);
    lockbt2 = true;
    }
    else
    {
        document.getElementById("nextButton").hidden = false;
    }
}

function button3clf()
{

    img3onmouseoverf();

    //alert("Не угадали");
    new Audio('audio/error.mp3').play();  
    document.getElementById("button3").style.backgroundColor = "#FF0000";
    //document.getElementById("ansImg3").hidden = false;
    document.getElementById("ansImg3").hidden = false;
    if (!lockbt3 && countTrueAns<2)
    {    
    //alert("btn3clicked " + countTrueAns);
    lockbt3 = true;
    }
    else
    {
        //document.getElementById("nextButton").hidden = false;
    }
}

function button4clf()
{

    img4onmouseoverf();


    //alert("Не угадали");
    new Audio('audio/ok.mp3').play(); 
    document.getElementById("button4").style.backgroundColor = "#00FF00";
    //document.getElementById("ansImg3").hidden = false;
    document.getElementById("ansImg4").hidden = false;
    if (!lockbt4 && countTrueAns<2)
    {
        countTrueAns++;
        //alert("btn4clicked " + countTrueAns);
        lockbt4 = true;
    }
    else
    {
        document.getElementById("nextButton").hidden = false;
    }
}

function button5clf()
{

    img5onmouseoverf();
    

    new Audio('audio/ok.mp3').play(); 
    //document.getElementById("nextButton").hidden = false;
    document.getElementById("button5").style.backgroundColor = "#00FF00";
    //document.getElementById("mainImage").src = "img/0/0000_.jpg";
    //document.getElementById("mainImage").hidden = true;
    //document.getElementById("mainImageResult").hidden = false;
    //mainImageResult
    document.getElementById("ansImg5").hidden = false;
    if (!lockbt5 && countTrueAns<2)
    {
    //countTrueAns++;
    //alert("btn5clicked " + countTrueAns);
    lockbt5 = true;
    }
    else
    {
        //document.getElementById("nextButton").hidden = false;
    }
}




function nextButtonclf()
{
    new Audio('audio/click.mp3').play(); 
    document.location.href = "q6.html";
}






function img0onmouseoverf()
{
    //document.getElementById("").
    document.getElementById("mainImage").src = "img/5/pas.png";
    document.getElementById("mainImage").style.zoom = "100%";
}

function img1onmouseoverf()
{
    //document.getElementById("").
    document.getElementById("mainImage").src = "img/5/may1.png";
    document.getElementById("mainImage").style.zoom = "200%";
}

function img2onmouseoverf()
{
    //document.getElementById("").
    document.getElementById("mainImage").src = "img/5/esn1.png";
    document.getElementById("mainImage").style.zoom = "180%";
}

function img3onmouseoverf()
{
    //document.getElementById("").
    document.getElementById("mainImage").src = "img/5/brs1.png";
    document.getElementById("mainImage").style.zoom = "90%";
}

function img4onmouseoverf()
{
    //document.getElementById("").
    document.getElementById("mainImage").src = "img/5/axm1.png";
    document.getElementById("mainImage").style.zoom = "150%";
}

function img5onmouseoverf()
{
    //document.getElementById("").
    document.getElementById("mainImage").src = "img/5/axm1.png";
    document.getElementById("mainImage").style.zoom = "150%";
}