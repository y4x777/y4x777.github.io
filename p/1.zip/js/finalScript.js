function startbclf()
{
    //alert("startButtonClicked");

    new Audio('audio/win.wav').play();
    
    setTimeout(() => document.location.href="index.html", 2000);

    
}

function playWinSoundf()
{
    //new Audio('audio/win.wav').play();
    //new Audio('audio/win.wav').play();

    //setTimeout(startbclf(), 10000);
    //setTimeout(() => startbclf(), 1000);



        //new Audio('audio/win.wav').play();
        //new Audio('audio/win.wav').play();

        //setTimeout(startbclf(), 10000);
        setTimeout(() => new Audio('audio/win.wav').play(), 100);

        setTimeout(() => document.location.href="index.html", 120000);
    
}