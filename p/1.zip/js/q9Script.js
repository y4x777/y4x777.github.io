function img0clf()
{
    //alert("Не угадали");
    new Audio('audio/error.mp3').play(); 
    //document.getElementById("divAns0").style.backgroundColor = "#FF0000";
    document.getElementById("ansImg0").hidden = false;
}

function button0clf()
{
    new Audio('audio/error.mp3').play(); 
    document.getElementById("button0").style.backgroundColor = "#FF0000";
    //document.getElementById("ansImg2").hidden = false;
    document.getElementById("ansImg0").hidden = false;
}

function button1clf()
{
    new Audio('audio/ok.mp3').play(); 
    document.getElementById("nextButton").hidden = false;
    document.getElementById("button1").style.backgroundColor = "#00FF00";
    document.getElementById("mainImage").src = "img/0/0000_.jpg";
    document.getElementById("mainImage").hidden = true;
    document.getElementById("mainImageResult").hidden = false;
    //mainImageResult
    document.getElementById("ansImg1").hidden = false;
}

function button2clf()
{
    //alert("Не угадали");
    new Audio('audio/error.mp3').play(); 
    document.getElementById("button2").style.backgroundColor = "#FF0000";
    //document.getElementById("ansImg3").hidden = false;
    document.getElementById("ansImg2").hidden = false;
}

function button3clf()
{
    //alert("Не угадали");
    new Audio('audio/error.mp3').play(); 
    document.getElementById("button3").style.backgroundColor = "#FF0000";
    //document.getElementById("ansImg3").hidden = false;
    document.getElementById("ansImg3").hidden = false;
}



function nextButtonclf()
{
    new Audio('audio/click.mp3').play(); 
    document.location.href = "q10.html";
}